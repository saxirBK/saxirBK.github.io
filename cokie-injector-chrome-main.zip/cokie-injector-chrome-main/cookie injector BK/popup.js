document.getElementById("injectCookie").addEventListener("click", () => {
    const name = document.getElementById("cookieName").value;
    const value = document.getElementById("cookieValue").value;
    const domain = document.getElementById("cookieDomain").value;

    if (!name || !value || !domain) {
        alert("Todos los campos son obligatorios.");
        return;
    }

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const url = tabs[0].url;

        chrome.runtime.sendMessage({
            action: "setCookie",
            url: url,
            name: name,
            value: value,
            domain: domain
        }, (response) => {
            if (response.success) {
                alert("Disfruta!");
            } else {
                alert("hou,hou");
            }
        });
    });
});
