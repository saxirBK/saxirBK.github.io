chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "setCookie") {
        chrome.cookies.set({
            url: message.url,
            name: message.name,
            value: message.value,
            domain: message.domain,
            path: "/"
        }, (cookie) => {
            sendResponse({ success: true });
        });
    }
    return true;
});
